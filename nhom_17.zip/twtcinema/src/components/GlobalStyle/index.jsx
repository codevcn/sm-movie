import './GlobalStyle.scss';

function GlobalStyle({ children }) {
    return children;
}

export default GlobalStyle;
