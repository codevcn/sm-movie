import logo from './movie-logo.jpg';
import background from './background.jpg';
import avatar from './noAvatar.jpg';

const image = {
    logo,
    background,
    avatar,
};

export default image;
