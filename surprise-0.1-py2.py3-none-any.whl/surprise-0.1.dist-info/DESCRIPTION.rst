Please use scikit-surprise(https://pypi.python.org/pypi/scikit-surprise/) instead.


